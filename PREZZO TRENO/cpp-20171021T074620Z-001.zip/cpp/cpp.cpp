#include <iostream>
#include <cmath>
#include <string>
using namespace std;

int main(){

int km, anni, classe;
string treno;
bool militare;
float prezzo;



cout<<"dammi la distanza in km"<<endl;
cin>>km;

cout<<"dammi l'eta' del passeggero"<<endl;
cin>>anni;

cout<<"dammi il tipo di treno"<<"(frecciarossa/frecciaargento/QBB/regionale)"<<endl;
cin>>treno;

cout<<"dammi la classe (1/2/3)"<<endl;
cin>>classe;

cout<<"militare? (true/false)"<<endl;
cin>>militare;


if(km<20){prezzo = 0,2*km;}

if(km>=20 and km<80){prezzo = 0,1*km;}

if(km>=80 and km<200){prezzo=0,05*km;}

if(km>=200){prezzo = 0,025*km;}
     
if(anni<10 or anni>=75){prezzo = prezzo - prezzo*50/100;}

if(treno =="frecciarossa"){prezzo = prezzo + prezzo*75/100;}

if(treno =="frecciaargento"){prezzo = prezzo+prezzo*50/100;}
    
if(treno == "QBB"){prezzo = prezzo + prezzo;}
  
if(classe==3){prezzo = prezzo - prezzo*50/100;}

if(classe == 1){prezzo = prezzo + (prezzo * 100)/100;}
        
if(militare==true){prezzo = prezzo - prezzo*80/10;}
    
cout<<"il prezzo finale del biglietto per la distanza di "<<km<<" kilometri"<<" e classe"<<classe<<"col treno "<<treno<<" e il passeggero di "<<anni<<" anni"<<"e' €"<<prezzo<<endl;



}