//
//  main.cpp
//  Database Ospedale
//
//  Created by EDON HAJRULI 3AUA on 03/11/17.
//
//  PROGRAMMA PER FACILITARE LA GESTIONE DI UN GRUPPO DI PAZIENTI IN UNA TABELLA DI ORGANIZZAZIONE
//
//  RIGA 64 - CHIEDERE AL PROF

#include <iostream>
#include <string>
#include <cmath>
using namespace std;

int main() {
    int i, N, trovato, scelta;
    cout<<"Dammi il numero di pazienti: ";
    cin>>N;
    int anni[N], stanza[N], nmag, nmin, annimax, somma, reddito[N], nmalattia, redditoMin, redditoMax;
    string nomi[N], malattia[N], genere[N], magmin[N], ricerca, nome ;
    
    for(i=0;i<N;i++){
        cout<<"dammi il nome del "<<i+1<<" paziente";
        cin>>nomi[i];
        cout<<endl<<"dammi la malattia: ";
        cin>>malattia[i];
        cout<<endl<<"dammi il genere: maschio/femmina ";
        cin>>genere[i];
        cout<<endl<<"dammi il numero di stanza: ";
        cin>>stanza[i];
        cout<<endl<<"dammmi gli anni del paziente: ";
        cin>>anni[i];
        cout<<"dammi il reddito annuale del paziente: ";
        cin>>reddito[i];
        
        
        if(anni[i]<18){
            magmin[i]= "minorenne";
        }
        if(anni[i]>18){
            magmin[i]= "maggiorenne";
        }
        
    }//fine for
    cout<<"tabella database ospedale"<<endl;
    cout<<"NOMI | STANZA | GENERE | MALATTIA | ANNI | ETA | REDDITO"<<endl<<endl;
    
    for(i=0;i<N;i++){
        cout<<nomi[i]<<" | "<<stanza[i]<<" | "<<genere[i]<<" | "<<malattia[i]<<" | "<<anni[i]<<" | "<<magmin[i]<<" | "<<reddito[i]<<endl;
    }
    cout<<endl<<endl<<"premi un tasto per continuare al menu";
    system(pause);
    
    
    
    do{
        
        trovato = 0;
        
        system("clear");
        
        cout<<" --------------------------------------------- "<<endl;
        cout<<"|  a/A  numero massimo di anni                |"<<endl;
        cout<<"|  b/B  media degli anni                      |"<<endl;
        cout<<"|  c/C  la stanza col numero max di pazienti  |"<<endl; // chiedere al prof. Martinelli
        cout<<"|  d/D  numero di pazienti con det. malattia  |"<<endl;
        cout<<"|  e/E  ristampa tabella pazienti             |"<<endl;
        cout<<"|  f/F  numero maggiorenni e minorenni        |"<<endl;
        cout<<"|  g/G  il paziente con il reddito piu alto   |"<<endl;
        cout<<"|  h/H  ricerca per nome                      |"<<endl;
        cout<<"|  i/I  ricerca per malattia                  |"<<endl;
        cout<<"|  j/J  ricerca per stanza                    |"<<endl;
        cout<<"|  k/K  ricerca per anni                      |"<<endl;
        cout<<"|  l/L  ricerca per intervallo di reddito     |"<<endl;
        cout<<"|  m/M  esci                                  |"<<endl;
        cout<<" --------------------------------------------- "<<endl;
        
        
        cin>>scelta;
        
        switch (scelta) {
                
            case "a": //numero massimo di anni
            case "A": //
                
                system("clear");
                annimax = anni[0];
                for(i=0;i<N;i++){
                    if(anni[i]>annimax){
                        annimax = anni[i];
                        nomi[i] = nome;
                    }
                }
                cout<<"La persona piu anziana e' "<<nome<<" ed ha "<<annimax<<" anni"<<endl;
                system("pause");
                
                break;
                
            case "b": //media degli anni
            case "B": //
                
                system("clear");
                somma=0;
                for(i=1;i<N;i++){
                    somma=somma + anni[i];
                }
                media = somma / N;
                system("pause");
                
                break;
                
            case "c": //la stanza col numero max di pazienti
            case "C": //
                
                //Chiedere al prof martinelli
                system("clear");
                
                system("pause");
                
                break;
                
            case "d": //numero di pazienti con det. malattia
            case "D":
                
                system("clear");
                
                cout<<"dammi la malattia da cercare quanti pazienti hanno quella malattia: ";
                cin>>ricerca;
                
                nmalattia = 0;
                for(i=0;i<N;i++){
                    
                    if(ricerca = malattia[i]){
                        nmalattia++;
                    }
                }
                cout<<"i pazienti che hanno la malattia "<<ricerca<<" sono in "<<nmalattia;
                
                system("pause");
                
                break;
                
            case "e": //ristampa tabella pazienti
            case "E": //
                
                system("clear");
                
                cout<<"tabella database ospedale"<<endl;
                cout<<"NOMI | STANZA | GENERE | MALATTIA | ANNI | ETA | REDDITO"<<endl<<endl;
                
                for(i=0;i<N;i++){
                    cout<<nomi[i]<<" | "<<stanza[i]<<" | "<<genere[i]<<" | "<<malattia[i]<<" | "<<anni[i]<<" | "<<magmin[i]<<" | "<<reddito[i]<<endl;
                }
                
                system("pause");
                
                break
                
            case "f": //numero maggiorenni e minorenni
            case "F": //
                
                system("clear");
                
                nmag = 0;
                nmin = 0;
                
                for(i=0;i<N;i++){
                    
                    if(magmin[i] == "minorenne"){
                        nmin++;
                    }
                    else{
                        nmag++;
                    }
                }
                cout<<"il numero di maggiorenni e': "<<nmag<<endl<<"il numero di minorenni e': "<<nmin<<endl<<endl;
                system("pause");
                
                break;
                
            case "g": //il paziente con il reddito piu alto
            case "G": //
                
                system("clear");
                
                redditoMax = reddito[0];
                for(i=0;i<N;i++){
                    if(reddito[i] > reddito){
                        redditoMax = reddito[i];
                        nome = nomi[i];
                    }
                }
                
                cout<<"Il reddito piu grande e' di "<<redditoMax<<" euro all'anno del paziente "<<nome;
                system("pause");
                
                break;
                
            case "h": //ricerca per nome
            case "H": //
                
                do{
                    
                    system("clear");
                    
                    cout<<"dammi un nome da cercare: ";
                    cin>>nome;
                    
                    for(i=0;i<N;i++){
                        
                        if(nome=nomi[i]){
                            
                            trovato = 1;
                            cout<<"tabella database ospedale"<<endl;
                            cout<<"NOMI | STANZA | GENERE | MALATTIA | ANNI | ETA | REDDITO"<<endl<<endl;
                            
                            for(i=0;i<N;i++){
                                cout<<nomi[i]<<" | "<<stanza[i]<<" | "<<genere[i]<<" | "<<malattia[i]<<" | "<<anni[i]<<" | "<<magmin[i]<<" | "<<reddito[i]<<endl;
                            }
                            system("pause");
                        }
                    }
                    if(trovato == 0){
                        cout<<"la persona cercata non e' stata trovata"<<endl<<endl;
                    }
                    trovato = 0;
                    
                    cout<<"vuoi efetture un'altra ricerca? si/no: ";
                    cin>>scelta;
                    system("pause");
                    
                }while(scelta != no);
                
                break;
                
            case "i": //ricerca per malattia
            case "I": //
                
                do{
                    
                    system("clear");
                    
                    cout<<"dammi una malattia da cercare: ";
                    cin>>ricerca;
                    
                    for(i=0;i<N;i++){
                        
                        if(ricerca=nomi[i]){
                            
                            trovato = 1;
                            cout<<"tabella database ospedale"<<endl;
                            cout<<"NOMI | STANZA | GENERE | MALATTIA | ANNI | ETA | REDDITO"<<endl<<endl;
                            
                            for(i=0;i<N;i++){
                                cout<<nomi[i]<<" | "<<stanza[i]<<" | "<<genere[i]<<" | "<<malattia[i]<<" | "<<anni[i]<<" | "<<magmin[i]<<" | "<<reddito[i]<<endl;
                            }
                            system("pause");
                        }
                    }
                    
                    if(trovato == 0){
                        cout<<"la persona cercata non e' stata trovata"<<endl<<endl;
                    }
                    
                    trovato = 0;
                    
                    cout<<"vuoi efetture un'altra ricerca? si/no: ";
                    cin>>scelta;
                    system("pause");
                    
                }while(scelta != "no");
                
                break;
                
            case "j": //ricerca per stanza
            case "J": //
                
                do{
                    
                    system("clear");
                    
                    cout<<"dammi il numero di  stanza del paziente da cercare: ";
                    cin>>ricerca;
                    
                    for(i=0;i<N;i++){
                        
                        if(ricerca == stanza[i]){
                            
                            trovato = 1;
                            cout<<"tabella database ospedale"<<endl;
                            cout<<"NOMI | STANZA | GENERE | MALATTIA | ANNI | ETA | REDDITO"<<endl<<endl;
                            
                            for(i=0;i<N;i++){
                                cout<<nomi[i]<<" | "<<stanza[i]<<" | "<<genere[i]<<" | "<<malattia[i]<<" | "<<anni[i]<<" | "<<magmin[i]<<" | "<<reddito[i]<<endl;
                            }
                            
                            system("pause");
                        }
                    }
                    
                    if(trovato == 0){
                        cout<<"la persona cercata non e' stata trovata"<<endl<<endl;
                    }
                    
                    trovato = 0;
                    
                    cout<<"vuoi efetture un'altra ricerca? si/no: ";
                    cin>>scelta;
                    system("pause");
                    
                }while(scelta != "no");
                
                break;
                
            case "k": //ricerca per anni
            case "K": //
                
                do{
                    
                    system("clear");
                    
                    cout<<"dammi gli anni del paziente da cercare: ";
                    cin>>ricerca;
                    
                    for(i=0;i<N;i++){
                        
                        if(ricerca == anni[i]){
                            
                            trovato = 1;
                            cout<<"tabella database ospedale"<<endl;
                            cout<<"NOMI | STANZA | GENERE | MALATTIA | ANNI | ETA | REDDITO"<<endl<<endl;
                            
                            for(i=0;i<N;i++){
                                cout<<nomi[i]<<" | "<<stanza[i]<<" | "<<genere[i]<<" | "<<malattia[i]<<" | "<<anni[i]<<" | "<<magmin[i]<<" | "<<reddito[i]<<endl;
                            }
                            
                            system("pause");
                        }
                    }
                    
                    if(trovato == 0){
                        cout<<"la persona cercata non e' stata trovata"<<endl<<endl;
                    }
                    
                    trovato = 0;
                    
                    cout<<"vuoi efetture un'altra ricerca? si/no: ";
                    cin>>scelta;
                    system("pause");
                    
                }while(scelta != "no");
                
                break;
                
            case "l": //ricerca per intervallo di reddito
            case "L": //
                
                do{
                    
                    system("clear");
                    
                    cout<<"dammi il numero MINIMO di reddito del intervallo da cercare: ";
                    cin>>redditoMin;
                    cout<<endl<<"Dammi il numero MASSIMO del intervallo da cercare: ";
                    cin>>redditoMax;
                    
                    for (i=0; i<N; i++) {
                        if(reddito[i] <= redditoMin and reddito[i] >= redditoMax){
                            
                            trovato = 1;
                            cout<<"tabella database ospedale"<<endl;
                            cout<<"NOMI | STANZA | GENERE | MALATTIA | ANNI | ETA | REDDITO"<<endl<<endl;
                            
                            for(i=0;i<N;i++){
                                cout<<nomi[i]<<" | "<<stanza[i]<<" | "<<genere[i]<<" | "<<malattia[i]<<" | "<<anni[i]<<" | "<<magmin[i]<<" | "<<reddito[i]<<endl;
                            }
                            
                            system("pause");
                            
                        }
                    }
                    
                    if(trovato == 0){
                        cout<<"la persona cercata non e' stata trovata"<<endl<<endl;
                    }
                    
                    trovato = 0;
                    
                    cout<<"vuoi efetture un'altra ricerca? si/no: ";
                    cin>>scelta;
                    system("pause");
                    
                }while(scelta != "no");
                
            case "m":
            case "M":
                break;
                
            default:
                break;
                
        }//fine switch
        
        
        if(scelta != "a" or scelta != "A" or scelta != "b" or scelta != "B" or scelta != "c" or scelta != "C" or scelta != "d" or scelta != "D" or scelta != "e" or scelta != "E" or scelta != "f" or scelta != "F" or scelta != "g" or scelta != "G" or scelta != "h" or scelta != "H" or scelta != "i" or scelta != "I" or scelta != "j" or scelta != "J" or scelta != "k" or scelta != "K" or scelta != "l" or scelta != "L" scelta != "m" or scelta != "M")
        {
            
            cout<<"premere un tasto per tornare al menu principale";
            system("pause");
            
        }
        
        
    }while(scelta != m or scelta =! M)//fine do principale
        
        return 0;
}//fine main








































